# 有痔青年 - React Native 版

这是一款专为关注肠道健康的年轻人设计的健康追踪应用的原生移动端版本。

## 技术栈

- **React Native** (Expo) - 跨平台移动应用框架
- **TypeScript** - 类型安全
- **NativeWind** - Tailwind CSS for React Native
- **React Native Reanimated** - 高性能动画
- **@gorhom/bottom-sheet** - 原生底部抽屉组件
- **AsyncStorage** - 本地数据持久化

## 迁移特性

### ✅ 无损迁移完成

1. **UI 组件替换**
   - `div` → `View`
   - `span/p` → `Text`
   - `button` → `TouchableOpacity/Pressable`
   - 图标使用 `lucide-react-native`

2. **Tailwind 样式保留**
   - 所有 `className` 样式完全保留
   - 使用 NativeWind 实现相同的视觉效果
   - 颜色、圆角、间距 100% 一致

3. **动画效果转换**
   - CSS 动画 → React Native Animated API
   - Dashboard 入场动画（卡片交错滑入）
   - 主按钮呼吸动画
   - 页面切换滑动动画
   - 底部抽屉使用 @gorhom/bottom-sheet

4. **业务逻辑保留**
   - 所有 React Hooks 完全保留
   - TypeScript 类型定义不变
   - 数据存储从 localStorage 迁移到 AsyncStorage

## 项目结构

```
mobile-app/
├── App.tsx                 # 主入口
├── src/
│   ├── screens/
│   │   ├── Dashboard.tsx      # 首页仪表盘
│   │   ├── RecordSheet.tsx    # 记录表单（Bottom Sheet）
│   │   ├── HistoryCalendar.tsx # 历史日历
│   │   ├── StatsPage.tsx      # 统计页面
│   │   └── SettingsPage.tsx   # 设置页面
│   ├── hooks/
│   │   └── usePoopRecords.ts  # 数据管理 Hook
│   ├── types/
│   │   └── index.ts           # TypeScript 类型
│   └── lib/
│       └── utils.ts           # 工具函数
├── global.css              # Tailwind 样式入口
├── tailwind.config.js      # Tailwind 配置
├── metro.config.js         # Metro 配置
└── app.json                # Expo 配置
```

## 运行项目

### 前置要求

- Node.js 16+
- npm 或 yarn
- Expo CLI (`npm install -g expo-cli`)
- iOS: Xcode (Mac only)
- Android: Android Studio + SDK

### 安装依赖

```bash
cd mobile-app
npm install
```

### 启动开发服务器

```bash
# 启动 Expo 开发服务器
npx expo start

# 在 iOS 模拟器运行
i

# 在 Android 模拟器运行
a

# 在 Web 浏览器运行
w
```

### 构建发布版本

```bash
# iOS 构建
npx expo build:ios

# Android 构建
npx expo build:android
```

## 与原 Web 版本的差异

| 特性 | Web 版本 | React Native 版本 |
|------|----------|-------------------|
| 存储 | localStorage | AsyncStorage |
| 底部抽屉 | 自定义 CSS | @gorhom/bottom-sheet |
| 动画 | CSS + Framer Motion | Animated API + Reanimated |
| 图标 | Lucide React | Lucide React Native |
| 导航 | 条件渲染 | 条件渲染 + 滑动动画 |

## 注意事项

1. **数据导出**: 由于 React Native 没有浏览器的下载功能，数据导出需要使用 `expo-file-system` 或 `react-native-fs` 来实现文件保存。

2. **推送通知**: 每日提醒功能需要配置 Expo Notifications。

3. **深色模式**: 当前为 UI 占位，完整实现需要配置主题系统。

## 许可证

MIT
