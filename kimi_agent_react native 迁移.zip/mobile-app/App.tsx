import React, { useState, useCallback } from 'react';
import { View, StatusBar, Animated } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Dashboard } from './src/screens/Dashboard';
import { RecordSheet } from './src/screens/RecordSheet';
import { HistoryCalendar } from './src/screens/HistoryCalendar';
import { StatsPage } from './src/screens/StatsPage';
import { SettingsPage } from './src/screens/SettingsPage';
import { usePoopRecords } from './src/hooks/usePoopRecords';
import type { PoopRecord } from './src/types';

type Page = 'dashboard' | 'history' | 'stats' | 'settings';

// Toast component
const Toast = ({ message, visible, onHide }: { message: string; visible: boolean; onHide: () => void }) => {
  const fadeAnim = React.useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    if (visible) {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();
      const timer = setTimeout(() => {
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }).start(onHide);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [visible, onHide]);

  if (!visible) return null;

  return (
    <Animated.View 
      className="absolute top-20 left-4 right-4 bg-white rounded-2xl p-4 z-50"
      style={{
        opacity: fadeAnim,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 12,
        elevation: 8,
      }}
    >
      <View className="flex-row items-center gap-2">
        <View 
          className="w-6 h-6 rounded-full items-center justify-center"
          style={{ backgroundColor: '#2A9D8F' }}
        >
          <Text className="text-white text-xs">✓</Text>
        </View>
        <Text className="flex-1 font-semibold text-[#264653]">{message}</Text>
      </View>
    </Animated.View>
  );
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [isRecordSheetOpen, setIsRecordSheetOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastVisible, setToastVisible] = useState(false);

  const { 
    records, 
    isLoaded, 
    addRecord, 
    getTodayRecords, 
    getStats,
    exportData,
    clearAllData 
  } = usePoopRecords();

  const stats = getStats();
  const todayRecords = getTodayRecords();

  const showToast = useCallback((message: string) => {
    setToastMessage(message);
    setToastVisible(true);
  }, []);

  const hideToast = useCallback(() => {
    setToastVisible(false);
  }, []);

  // Handle record save
  const handleSaveRecord = useCallback((record: Omit<PoopRecord, 'id'>) => {
    addRecord(record);
    showToast('记录保存成功！继续保持良好的健康习惯 💪');
  }, [addRecord, showToast]);

  // Handle export data
  const handleExportData = useCallback(() => {
    const data = exportData();
    // In a real app, you would use expo-file-system or react-native-fs to save the file
    console.log('Export data:', data);
    showToast('数据导出成功！');
  }, [exportData, showToast]);

  // Handle clear data
  const handleClearData = useCallback(() => {
    clearAllData();
    showToast('所有数据已清除');
  }, [clearAllData, showToast]);

  // Loading screen
  if (!isLoaded) {
    return (
      <GestureHandlerRootView className="flex-1">
        <SafeAreaProvider>
          <View className="flex-1 bg-[#f7f7f7] items-center justify-center">
            <View className="items-center">
              <Text className="text-6xl mb-4">💩</Text>
              <Text className="text-[#264653] font-semibold">加载中...</Text>
            </View>
          </View>
        </SafeAreaProvider>
      </GestureHandlerRootView>
    );
  }

  return (
    <GestureHandlerRootView className="flex-1">
      <SafeAreaProvider>
        <StatusBar barStyle="dark-content" backgroundColor="#f7f7f7" />
        
        <View className="flex-1 bg-[#f7f7f7]">
          {/* Main Dashboard */}
          <Dashboard
            stats={stats}
            todayCount={todayRecords.length}
            onRecordClick={() => setIsRecordSheetOpen(true)}
            onHistoryClick={() => setCurrentPage('history')}
            onStatsClick={() => setCurrentPage('stats')}
            onSettingsClick={() => setCurrentPage('settings')}
          />

          {/* Record Sheet (Bottom Sheet) */}
          <RecordSheet
            isOpen={isRecordSheetOpen}
            onClose={() => setIsRecordSheetOpen(false)}
            onSave={handleSaveRecord}
          />

          {/* History Calendar Page */}
          {currentPage === 'history' && (
            <HistoryCalendar
              records={records}
              onClose={() => setCurrentPage('dashboard')}
            />
          )}

          {/* Stats Page */}
          {currentPage === 'stats' && (
            <StatsPage
              records={records}
              stats={stats}
              onClose={() => setCurrentPage('dashboard')}
              onExport={handleExportData}
            />
          )}

          {/* Settings Page */}
          {currentPage === 'settings' && (
            <SettingsPage
              isOpen={currentPage === 'settings'}
              onClose={() => setCurrentPage('dashboard')}
              onClearData={handleClearData}
              onExportData={handleExportData}
            />
          )}

          {/* Toast */}
          <Toast 
            message={toastMessage} 
            visible={toastVisible} 
            onHide={hideToast} 
          />
        </View>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
