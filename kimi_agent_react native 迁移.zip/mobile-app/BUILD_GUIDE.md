# 有痔青年 - APK 构建指南

## 方法一：使用 Expo EAS Build（推荐，最简单）

### 1. 准备工作
```bash
# 安装 EAS CLI
npm install -g eas-cli

# 登录 Expo 账户（免费注册）
eas login
```

### 2. 配置项目
项目已配置好 `eas.json`，直接构建即可。

### 3. 构建 APK
```bash
cd mobile-app

# 构建预览版 APK
eas build -p android --profile preview

# 等待构建完成，下载链接会显示在终端
```

构建完成后，Expo 会提供一个下载链接，直接下载 APK 安装即可。

---

## 方法二：本地构建（需要 Android 环境）

### 1. 安装依赖
```bash
cd mobile-app
npm install
```

### 2. 安装 Android 开发环境
- 下载并安装 [Android Studio](https://developer.android.com/studio)
- 安装 Android SDK
- 配置环境变量 `ANDROID_HOME`

### 3. 生成本地项目
```bash
npx expo prebuild -p android
```

### 4. 构建 APK
```bash
cd android
./gradlew assembleRelease
```

APK 将生成在 `android/app/build/outputs/apk/release/app-release.apk`

---

## 方法三：使用 Expo Go 开发（无需构建）

### 1. 安装 Expo Go
在手机应用商店搜索 "Expo Go" 并安装

### 2. 启动开发服务器
```bash
cd mobile-app
npm install
npx expo start
```

### 3. 扫码运行
终端会显示二维码，用 Expo Go 扫描即可运行

---

## 常见问题

### Q: EAS Build 需要付费吗？
A: 免费额度每月 30 次构建，足够个人使用。

### Q: 如何修改应用名称和图标？
A: 修改 `app.json` 中的配置：
```json
{
  "expo": {
    "name": "你的应用名称",
    "icon": "./assets/icon.png"
  }
}
```

### Q: 构建失败怎么办？
A: 检查以下几点：
1. `app.json` 中的 `android.package` 必须是唯一的（如 `com.yourname.pooptracker`）
2. 图标尺寸必须符合要求（1024x1024）
3. 依赖版本是否兼容

---

## 文件说明

| 文件 | 说明 |
|------|------|
| `app.json` | Expo 配置文件 |
| `eas.json` | EAS Build 配置文件 |
| `package.json` | 依赖列表 |
| `src/` | 源代码目录 |
| `assets/` | 图标和启动图 |

---

## 快速开始

```bash
# 1. 进入项目目录
cd mobile-app

# 2. 安装依赖
npm install

# 3. 启动开发服务器
npx expo start

# 4. 按 'a' 在 Android 模拟器运行
# 或按 'w' 在浏览器运行
```
