import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { PoopRecord, StatsData, ChartData } from '@/types';

const STORAGE_KEY = 'poop_records_v1';

export function usePoopRecords() {
  const [records, setRecords] = useState<PoopRecord[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // 从AsyncStorage加载数据
  useEffect(() => {
    const loadRecords = async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          setRecords(parsed);
        }
      } catch (e) {
        console.error('Failed to parse records:', e);
      }
      setIsLoaded(true);
    };
    loadRecords();
  }, []);

  // 保存到AsyncStorage
  useEffect(() => {
    const saveRecords = async () => {
      if (isLoaded) {
        try {
          await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(records));
        } catch (e) {
          console.error('Failed to save records:', e);
        }
      }
    };
    saveRecords();
  }, [records, isLoaded]);

  // 添加记录
  const addRecord = useCallback((record: Omit<PoopRecord, 'id'>) => {
    const newRecord: PoopRecord = {
      ...record,
      id: Date.now().toString(),
    };
    setRecords(prev => [newRecord, ...prev]);
    return newRecord;
  }, []);

  // 删除记录
  const deleteRecord = useCallback((id: string) => {
    setRecords(prev => prev.filter(r => r.id !== id));
  }, []);

  // 获取今日记录
  const getTodayRecords = useCallback(() => {
    const today = new Date().toISOString().split('T')[0];
    return records.filter(r => r.date === today);
  }, [records]);

  // 获取统计数据
  const getStats = useCallback((): StatsData => {
    const today = new Date().toISOString().split('T')[0];
    
    // 计算连续打卡天数
    let streakDays = 0;
    const dates = [...new Set(records.map(r => r.date))].sort().reverse();
    
    for (let i = 0; i < dates.length; i++) {
      const date = dates[i];
      const expectedDate = new Date();
      expectedDate.setDate(expectedDate.getDate() - i);
      const expectedDateStr = expectedDate.toISOString().split('T')[0];
      
      if (date === expectedDateStr || (i === 0 && date === today)) {
        streakDays++;
      } else if (i > 0) {
        break;
      }
    }

    // 计算本月记录数
    const currentMonth = today.substring(0, 7);
    const thisMonthCount = records.filter(r => r.date.startsWith(currentMonth)).length;

    // 计算出血天数
    const bloodDays = new Set(records.filter(r => r.hasBlood).map(r => r.date)).size;

    // 计算平均疼痛指数
    const avgPainLevel = records.length > 0
      ? Math.round(records.reduce((sum, r) => sum + r.painLevel, 0) / records.length * 10) / 10
      : 0;

    // 上次排便时间
    const lastRecord = records[0];
    const lastPoopTime = lastRecord ? new Date(lastRecord.timestamp).toISOString() : null;

    return {
      totalRecords: records.length,
      streakDays,
      lastPoopTime,
      bloodDays,
      avgPainLevel,
      thisMonthCount,
    };
  }, [records]);

  // 获取图表数据（最近30天）
  const getChartData = useCallback((): ChartData[] => {
    const data: ChartData[] = [];
    const today = new Date();
    
    for (let i = 29; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dayRecords = records.filter(r => r.date === dateStr);
      const hasBlood = dayRecords.some(r => r.hasBlood);
      const avgPain = dayRecords.length > 0
        ? Math.round(dayRecords.reduce((sum, r) => sum + r.painLevel, 0) / dayRecords.length)
        : 0;
      
      data.push({
        date: dateStr,
        count: dayRecords.length,
        hasBlood,
        painLevel: avgPain,
      });
    }
    
    return data;
  }, [records]);

  // 获取指定月份的日历数据
  const getCalendarData = useCallback((year: number, month: number) => {
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    const daysInMonth = lastDay.getDate();
    const startDayOfWeek = firstDay.getDay();
    
    const calendar = [];
    const today = new Date().toISOString().split('T')[0];
    
    // 填充上个月的空白天
    for (let i = 0; i < startDayOfWeek; i++) {
      calendar.push(null);
    }
    
    // 填充当月日期
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const dayRecords = records.filter(r => r.date === dateStr);
      
      calendar.push({
        date: day,
        fullDate: dateStr,
        hasRecord: dayRecords.length > 0,
        hasBlood: dayRecords.some(r => r.hasBlood),
        painLevel: dayRecords.length > 0
          ? Math.round(dayRecords.reduce((sum, r) => sum + r.painLevel, 0) / dayRecords.length)
          : 0,
        isToday: dateStr === today,
        isCurrentMonth: true,
      });
    }
    
    return calendar;
  }, [records]);

  // 导出数据
  const exportData = useCallback(() => {
    return JSON.stringify(records, null, 2);
  }, [records]);

  // 清除所有数据
  const clearAllData = useCallback(async () => {
    setRecords([]);
    try {
      await AsyncStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.error('Failed to clear records:', e);
    }
  }, []);

  return {
    records,
    isLoaded,
    addRecord,
    deleteRecord,
    getTodayRecords,
    getStats,
    getChartData,
    getCalendarData,
    exportData,
    clearAllData,
  };
}
