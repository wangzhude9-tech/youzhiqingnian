// 排便记录数据模型
export interface PoopRecord {
  id: string;
  timestamp: number;
  date: string;
  time: string;
  hasBlood: boolean;
  bloodAmount?: BloodAmount;
  painLevel: number;
  note: string;
}

// 出血量类型
export type BloodAmount = 'minimal' | 'small' | 'medium' | 'large';

// 出血量标签
export const BloodAmountLabels: Record<BloodAmount, string> = {
  'minimal': '微量（仅手纸可见）',
  'small': '少量（表面带血）',
  'medium': '中量（滴状）',
  'large': '大量（喷射状/需就医警戒）',
};

// 疼痛表情映射
export const PainEmojis: Record<number, string> = {
  0: '😊',
  1: '🙂',
  2: '😌',
  3: '😐',
  4: '😕',
  5: '😣',
  6: '😖',
  7: '😫',
  8: '😩',
  9: '😭',
  10: '😱',
};

// 日历日期项
export interface CalendarDay {
  date: number;
  fullDate: string;
  hasRecord: boolean;
  hasBlood: boolean;
  painLevel: number;
  isToday: boolean;
  isCurrentMonth: boolean;
}

// 统计数据
export interface StatsData {
  totalRecords: number;
  streakDays: number;
  lastPoopTime: string | null;
  bloodDays: number;
  avgPainLevel: number;
  thisMonthCount: number;
}

// 图表数据
export interface ChartData {
  date: string;
  count: number;
  hasBlood: boolean;
  painLevel: number;
}

// 导航参数
export type RootStackParamList = {
  Dashboard: undefined;
  History: undefined;
  Stats: undefined;
  Settings: undefined;
};
