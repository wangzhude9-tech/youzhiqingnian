import { clsx, type ClassValue } from "clsx";

// 简化版 cn 函数（React Native 不需要 tailwind-merge）
export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

// 格式化时间显示
export function formatTimeAgo(timestamp: string | null): string {
  if (!timestamp) return '暂无记录';
  
  const now = new Date();
  const past = new Date(timestamp);
  const diffMs = now.getTime() - past.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  
  if (diffMins < 1) return '刚刚';
  if (diffMins < 60) return `${diffMins}分钟前`;
  if (diffHours < 24) return `${diffHours}小时前`;
  if (diffDays < 30) return `${diffDays}天前`;
  return past.toLocaleDateString('zh-CN');
}

// 格式化日期显示
export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('zh-CN', {
    month: 'short',
    day: 'numeric',
    weekday: 'short',
  });
}

// 获取当前时间字符串 HH:mm
export function getCurrentTime(): string {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
}

// 获取当前日期字符串 YYYY-MM-DD
export function getCurrentDate(): string {
  return new Date().toISOString().split('T')[0];
}

// 获取疼痛颜色
export function getPainColor(level: number): string {
  if (level <= 2) return 'bg-green-500';
  if (level <= 4) return 'bg-yellow-400';
  if (level <= 6) return 'bg-orange-400';
  if (level <= 8) return 'bg-red-400';
  return 'bg-red-600';
}

// 获取疼痛颜色（用于文本）
export function getPainTextColor(level: number): string {
  if (level <= 2) return 'text-green-500';
  if (level <= 4) return 'text-yellow-500';
  if (level <= 6) return 'text-orange-400';
  if (level <= 8) return 'text-red-400';
  return 'text-red-600';
}

// 获取疼痛文字描述
export function getPainText(level: number): string {
  if (level === 0) return '无感';
  if (level <= 2) return '轻微';
  if (level <= 4) return '轻度';
  if (level <= 6) return '中度';
  if (level <= 8) return '重度';
  return '剧痛';
}

// 生成唯一ID
export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}
