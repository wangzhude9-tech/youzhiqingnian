import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, Animated, Dimensions, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Calendar, BarChart3, Settings, Flame, Clock, CheckCircle2 } from 'lucide-react-native';
import { cn, formatTimeAgo } from '@/lib/utils';
import type { StatsData } from '@/types';

const { width } = Dimensions.get('window');

interface DashboardProps {
  stats: StatsData;
  todayCount: number;
  onRecordClick: () => void;
  onHistoryClick: () => void;
  onStatsClick: () => void;
  onSettingsClick: () => void;
}

export function Dashboard({
  stats,
  todayCount,
  onRecordClick,
  onHistoryClick,
  onStatsClick,
  onSettingsClick,
}: DashboardProps) {
  // Animated values
  const headerOpacity = useRef(new Animated.Value(0)).current;
  const headerTranslateY = useRef(new Animated.Value(-20)).current;
  
  const card1Opacity = useRef(new Animated.Value(0)).current;
  const card1TranslateX = useRef(new Animated.Value(-50)).current;
  
  const card2Opacity = useRef(new Animated.Value(0)).current;
  const card2TranslateX = useRef(new Animated.Value(50)).current;
  
  const card3Opacity = useRef(new Animated.Value(0)).current;
  const card3TranslateX = useRef(new Animated.Value(-50)).current;
  
  const card4Opacity = useRef(new Animated.Value(0)).current;
  const card4TranslateX = useRef(new Animated.Value(50)).current;
  
  const buttonScale = useRef(new Animated.Value(0)).current;
  const buttonOpacity = useRef(new Animated.Value(0)).current;
  
  const actionsOpacity = useRef(new Animated.Value(0)).current;
  const actionsTranslateY = useRef(new Animated.Value(50)).current;

  const [buttonPressed, setButtonPressed] = useState(false);

  // Breathing animation for main button
  const breatheScale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // Header animation
    Animated.parallel([
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 700,
        useNativeDriver: true,
      }),
      Animated.timing(headerTranslateY, {
        toValue: 0,
        duration: 700,
        useNativeDriver: true,
      }),
    ]).start();

    // Cards staggered animation
    const cardDelay = 100;
    
    Animated.parallel([
      Animated.sequence([
        Animated.delay(cardDelay),
        Animated.parallel([
          Animated.timing(card1Opacity, { toValue: 1, duration: 600, useNativeDriver: true }),
          Animated.timing(card1TranslateX, { toValue: 0, duration: 600, useNativeDriver: true }),
        ]),
      ]),
      Animated.sequence([
        Animated.delay(cardDelay * 2),
        Animated.parallel([
          Animated.timing(card2Opacity, { toValue: 1, duration: 600, useNativeDriver: true }),
          Animated.timing(card2TranslateX, { toValue: 0, duration: 600, useNativeDriver: true }),
        ]),
      ]),
      Animated.sequence([
        Animated.delay(cardDelay * 3),
        Animated.parallel([
          Animated.timing(card3Opacity, { toValue: 1, duration: 600, useNativeDriver: true }),
          Animated.timing(card3TranslateX, { toValue: 0, duration: 600, useNativeDriver: true }),
        ]),
      ]),
      Animated.sequence([
        Animated.delay(cardDelay * 4),
        Animated.parallel([
          Animated.timing(card4Opacity, { toValue: 1, duration: 600, useNativeDriver: true }),
          Animated.timing(card4TranslateX, { toValue: 0, duration: 600, useNativeDriver: true }),
        ]),
      ]),
    ]).start();

    // Main button animation
    Animated.sequence([
      Animated.delay(300),
      Animated.parallel([
        Animated.spring(buttonScale, {
          toValue: 1,
          friction: 5,
          tension: 40,
          useNativeDriver: true,
        }),
        Animated.timing(buttonOpacity, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
      ]),
    ]).start();

    // Actions animation
    Animated.sequence([
      Animated.delay(500),
      Animated.parallel([
        Animated.timing(actionsOpacity, { toValue: 1, duration: 700, useNativeDriver: true }),
        Animated.timing(actionsTranslateY, { toValue: 0, duration: 700, useNativeDriver: true }),
      ]),
    ]).start();

    // Breathing animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(breatheScale, {
          toValue: 1.02,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(breatheScale, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  const handleRecordPress = () => {
    setButtonPressed(true);
    Animated.sequence([
      Animated.timing(buttonScale, {
        toValue: 0.9,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(buttonScale, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setButtonPressed(false);
      onRecordClick();
    });
  };

  return (
    <SafeAreaView className="flex-1 bg-[#f7f7f7]">
      <StatusBar barStyle="dark-content" backgroundColor="#f7f7f7" />
      
      {/* Header */}
      <Animated.View 
        className="px-6 pt-4 pb-4"
        style={{
          opacity: headerOpacity,
          transform: [{ translateY: headerTranslateY }],
        }}
      >
        <View className="flex-row items-center justify-between">
          <View>
            <Text className="text-2xl font-bold text-[#264653]">有痔青年</Text>
            <Text className="text-sm text-[#777]">关爱自己，从每一次开始</Text>
          </View>
          <TouchableOpacity
            onPress={onSettingsClick}
            className="p-3 rounded-full bg-white shadow-sm"
            activeOpacity={0.7}
          >
            <Settings className="w-5 h-5 text-[#264653]" />
          </TouchableOpacity>
        </View>
      </Animated.View>

      {/* Stats Cards */}
      <View className="px-6 py-4 flex-row flex-wrap justify-between">
        {/* Last Poop Card */}
        <Animated.View 
          className="w-[48%] bg-white rounded-2xl p-4 shadow-sm mb-4"
          style={{
            opacity: card1Opacity,
            transform: [{ translateX: card1TranslateX }],
          }}
        >
          <View className="flex-row items-center gap-2 mb-2">
            <View className="w-8 h-8 rounded-full bg-[#2A9D8F]/10 items-center justify-center">
              <Clock className="w-4 h-4 text-[#2A9D8F]" />
            </View>
            <Text className="text-xs text-[#777]">距离上次</Text>
          </View>
          <Text className="text-lg font-bold text-[#264653]">
            {formatTimeAgo(stats.lastPoopTime)}
          </Text>
        </Animated.View>

        {/* Streak Card */}
        <Animated.View 
          className="w-[48%] bg-white rounded-2xl p-4 shadow-sm mb-4"
          style={{
            opacity: card2Opacity,
            transform: [{ translateX: card2TranslateX }],
          }}
        >
          <View className="flex-row items-center gap-2 mb-2">
            <View className="w-8 h-8 rounded-full bg-[#E9C46A]/20 items-center justify-center">
              <Flame className="w-4 h-4 text-[#E9C46A]" />
            </View>
            <Text className="text-xs text-[#777]">连续打卡</Text>
          </View>
          <Text className="text-lg font-bold text-[#264653]">
            {stats.streakDays} <Text className="text-sm font-normal text-[#777]">天</Text>
          </Text>
        </Animated.View>

        {/* Today Status Card */}
        <Animated.View 
          className="w-[48%] bg-white rounded-2xl p-4 shadow-sm"
          style={{
            opacity: card3Opacity,
            transform: [{ translateX: card3TranslateX }],
          }}
        >
          <View className="flex-row items-center gap-2 mb-2">
            <View className="w-8 h-8 rounded-full bg-[#F4A261]/20 items-center justify-center">
              <CheckCircle2 className="w-4 h-4 text-[#F4A261]" />
            </View>
            <Text className="text-xs text-[#777]">今日打卡</Text>
          </View>
          <Text className="text-lg font-bold text-[#264653]">
            {todayCount} <Text className="text-sm font-normal text-[#777]">次</Text>
          </Text>
        </Animated.View>

        {/* Monthly Count Card */}
        <Animated.View 
          className="w-[48%] bg-white rounded-2xl p-4 shadow-sm"
          style={{
            opacity: card4Opacity,
            transform: [{ translateX: card4TranslateX }],
          }}
        >
          <View className="flex-row items-center gap-2 mb-2">
            <View className="w-8 h-8 rounded-full bg-[#2A9D8F]/10 items-center justify-center">
              <BarChart3 className="w-4 h-4 text-[#2A9D8F]" />
            </View>
            <Text className="text-xs text-[#777]">本月记录</Text>
          </View>
          <Text className="text-lg font-bold text-[#264653]">
            {stats.thisMonthCount} <Text className="text-sm font-normal text-[#777]">次</Text>
          </Text>
        </Animated.View>
      </View>

      {/* Main CTA Button */}
      <View className="flex-1 items-center justify-center px-6 py-8">
        <Animated.View
          style={{
            opacity: buttonOpacity,
            transform: [{ scale: buttonScale }],
          }}
        >
          {/* Ripple rings */}
          <View className="absolute inset-0 rounded-full bg-[#2A9D8F]/20" 
            style={{ transform: [{ scale: 1.1 }] }} 
          />
          
          {/* Main button */}
          <TouchableOpacity
            onPress={handleRecordPress}
            activeOpacity={0.8}
            className="w-48 h-48 rounded-full items-center justify-center gap-3"
            style={{
              backgroundColor: '#2A9D8F',
              shadowColor: '#2A9D8F',
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.3,
              shadowRadius: 20,
              elevation: 10,
            }}
          >
            <Animated.Text 
              className="text-6xl"
              style={{ transform: [{ scale: breatheScale }] }}
            >
              💩
            </Animated.Text>
            <Text className="text-white font-bold text-lg">一键拉屎</Text>
          </TouchableOpacity>
        </Animated.View>

        <Animated.Text 
          className="mt-8 text-[#777] text-sm"
          style={{
            opacity: buttonOpacity,
            transform: [{ translateY: buttonPressed ? 4 : 0 }],
          }}
        >
          点击记录今天的排便情况
        </Animated.Text>
      </View>

      {/* Quick Actions */}
      <Animated.View 
        className="px-6 pb-8"
        style={{
          opacity: actionsOpacity,
          transform: [{ translateY: actionsTranslateY }],
        }}
      >
        <View className="bg-white rounded-2xl p-2 shadow-sm flex-row justify-around">
          <TouchableOpacity
            onPress={onHistoryClick}
            className="items-center gap-1 p-3 rounded-xl"
            activeOpacity={0.7}
          >
            <View className="w-10 h-10 rounded-full bg-[#2A9D8F]/10 items-center justify-center">
              <Calendar className="w-5 h-5 text-[#2A9D8F]" />
            </View>
            <Text className="text-xs text-[#264653]">历史</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            onPress={onStatsClick}
            className="items-center gap-1 p-3 rounded-xl"
            activeOpacity={0.7}
          >
            <View className="w-10 h-10 rounded-full bg-[#E9C46A]/20 items-center justify-center">
              <BarChart3 className="w-5 h-5 text-[#E9C46A]" />
            </View>
            <Text className="text-xs text-[#264653]">统计</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            onPress={onSettingsClick}
            className="items-center gap-1 p-3 rounded-xl"
            activeOpacity={0.7}
          >
            <View className="w-10 h-10 rounded-full bg-[#F4A261]/20 items-center justify-center">
              <Settings className="w-5 h-5 text-[#F4A261]" />
            </View>
            <Text className="text-xs text-[#264653]">设置</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
}
