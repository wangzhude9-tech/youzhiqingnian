import React, { useState, useMemo, useRef, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Animated, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Droplets, AlertCircle, X } from 'lucide-react-native';
import { cn, formatDate, getPainColor } from '@/lib/utils';
import type { PoopRecord } from '@/types';

const { width, height } = Dimensions.get('window');

interface HistoryCalendarProps {
  records: PoopRecord[];
  onClose: () => void;
}

const WEEKDAYS = ['日', '一', '二', '三', '四', '五', '六'];

export function HistoryCalendar({ records, onClose }: HistoryCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  // Animation values
  const slideAnim = useRef(new Animated.Value(width)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const detailSlideAnim = useRef(new Animated.Value(height)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (selectedDate) {
      Animated.timing(detailSlideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    } else {
      Animated.timing(detailSlideAnim, {
        toValue: height,
        duration: 300,
        useNativeDriver: true,
      }).start();
    }
  }, [selectedDate]);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth() + 1;

  // Get calendar data
  const calendarDays = useMemo(() => {
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    const daysInMonth = lastDay.getDate();
    const startDayOfWeek = firstDay.getDay();
    
    const days: ({
      date: number;
      fullDate: string;
      hasRecord: boolean;
      hasBlood: boolean;
      painLevel: number;
      isToday: boolean;
    } | null)[] = [];
    
    // Fill empty days
    for (let i = 0; i < startDayOfWeek; i++) {
      days.push(null);
    }
    
    const today = new Date().toISOString().split('T')[0];
    
    // Fill month days
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const dayRecords = records.filter(r => r.date === dateStr);
      
      days.push({
        date: day,
        fullDate: dateStr,
        hasRecord: dayRecords.length > 0,
        hasBlood: dayRecords.some(r => r.hasBlood),
        painLevel: dayRecords.length > 0
          ? Math.round(dayRecords.reduce((sum, r) => sum + r.painLevel, 0) / dayRecords.length)
          : 0,
        isToday: dateStr === today,
      });
    }
    
    return days;
  }, [year, month, records]);

  // Get selected date records
  const selectedDateRecords = useMemo(() => {
    if (!selectedDate) return [];
    return records.filter(r => r.date === selectedDate);
  }, [selectedDate, records]);

  const goToPrevMonth = () => {
    setCurrentDate(new Date(year, month - 2, 1));
    setSelectedDate(null);
  };

  const goToNextMonth = () => {
    setCurrentDate(new Date(year, month, 1));
    setSelectedDate(null);
  };

  const handleDayClick = (dateStr: string, hasRecord: boolean) => {
    if (hasRecord) {
      setSelectedDate(dateStr);
    }
  };

  const handleClose = () => {
    Animated.parallel([
      Animated.timing(slideAnim, {
        toValue: width,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start(() => {
      onClose();
    });
  };

  return (
    <Animated.View 
      className="absolute inset-0 bg-[#f7f7f7] z-50"
      style={{
        transform: [{ translateX: slideAnim }],
        opacity: fadeAnim,
      }}
    >
      <SafeAreaView className="flex-1">
        {/* Header */}
        <View className="bg-white px-6 pt-4 pb-4 shadow-sm">
          <View className="flex-row items-center justify-between">
            <TouchableOpacity
              onPress={handleClose}
              className="p-2 -ml-2 rounded-full"
              activeOpacity={0.7}
            >
              <ChevronLeft className="w-6 h-6 text-[#264653]" />
            </TouchableOpacity>
            <Text className="text-xl font-bold text-[#264653]">历史记录</Text>
            <View className="w-10" />
          </View>
        </View>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          {/* Calendar */}
          <View className="px-4 py-6">
            {/* Month Navigation */}
            <View className="flex-row items-center justify-between mb-6">
              <TouchableOpacity
                onPress={goToPrevMonth}
                className="p-2 rounded-full"
                activeOpacity={0.7}
              >
                <ChevronLeft className="w-5 h-5 text-[#264653]" />
              </TouchableOpacity>
              <View className="flex-row items-center gap-2">
                <CalendarIcon className="w-5 h-5 text-[#2A9D8F]" />
                <Text className="text-lg font-bold text-[#264653]">
                  {year}年{month}月
                </Text>
              </View>
              <TouchableOpacity
                onPress={goToNextMonth}
                className="p-2 rounded-full"
                activeOpacity={0.7}
              >
                <ChevronRight className="w-5 h-5 text-[#264653]" />
              </TouchableOpacity>
            </View>

            {/* Weekday Headers */}
            <View className="flex-row mb-2">
              {WEEKDAYS.map(day => (
                <View key={day} className="flex-1 items-center py-2">
                  <Text className="text-sm text-[#777]">{day}</Text>
                </View>
              ))}
            </View>

            {/* Calendar Grid */}
            <View className="flex-row flex-wrap">
              {calendarDays.map((day, index) => (
                <View
                  key={index}
                  className="w-[14.28%] aspect-square p-1"
                >
                  {day && (
                    <TouchableOpacity
                      className={cn(
                        "w-full h-full rounded-xl items-center justify-center",
                        day.isToday && "border-2 border-[#2A9D8F]",
                        day.hasRecord 
                          ? day.hasBlood
                            ? "bg-[#E76F51]/10"
                            : "bg-[#2A9D8F]/10"
                          : "bg-transparent"
                      )}
                      onPress={() => handleDayClick(day.fullDate, day.hasRecord)}
                      activeOpacity={day.hasRecord ? 0.7 : 1}
                      disabled={!day.hasRecord}
                    >
                      <Text className={cn(
                        "text-sm font-medium",
                        day.isToday ? "text-[#2A9D8F]" : "text-[#264653]"
                      )}>
                        {day.date}
                      </Text>
                      {day.hasRecord && (
                        <View className="flex-row items-center gap-0.5 mt-0.5">
                          {day.hasBlood && (
                            <Droplets className="w-3 h-3 text-[#E76F51]" />
                          )}
                          {day.painLevel > 5 && (
                            <AlertCircle className="w-3 h-3 text-[#F4A261]" />
                          )}
                        </View>
                      )}
                    </TouchableOpacity>
                  )}
                </View>
              ))}
            </View>

            {/* Legend */}
            <View className="flex-row items-center justify-center gap-6 mt-6">
              <View className="flex-row items-center gap-1.5">
                <View className="w-3 h-3 rounded-full bg-[#2A9D8F]/20" />
                <Text className="text-xs text-[#777]">正常</Text>
              </View>
              <View className="flex-row items-center gap-1.5">
                <View className="w-3 h-3 rounded-full bg-[#E76F51]/20" />
                <Text className="text-xs text-[#777]">有出血</Text>
              </View>
              <View className="flex-row items-center gap-1.5">
                <View className="w-3 h-3 rounded-full border-2 border-[#2A9D8F]" />
                <Text className="text-xs text-[#777]">今天</Text>
              </View>
            </View>
          </View>
        </ScrollView>

        {/* Selected Date Details */}
        {selectedDate && (
          <Animated.View 
            className="absolute inset-x-0 bottom-0 bg-white rounded-t-3xl shadow-2xl z-10"
            style={{ 
              maxHeight: height * 0.6,
              transform: [{ translateY: detailSlideAnim }],
            }}
          >
            {/* Handle */}
            <View className="items-center pt-3 pb-1">
              <View className="w-12 h-1.5 bg-gray-300 rounded-full" />
            </View>
            
            {/* Header */}
            <View className="flex-row items-center justify-between px-6 py-3 border-b border-gray-100">
              <Text className="text-lg font-bold text-[#264653]">
                {formatDate(selectedDate)}
              </Text>
              <TouchableOpacity
                onPress={() => setSelectedDate(null)}
                className="p-2 rounded-full bg-gray-100"
                activeOpacity={0.7}
              >
                <X className="w-5 h-5 text-[#777]" />
              </TouchableOpacity>
            </View>
            
            {/* Records List */}
            <ScrollView className="px-6 py-4" style={{ maxHeight: height * 0.4 }}>
              <View className="space-y-3">
                {selectedDateRecords.map((record, index) => (
                  <View
                    key={record.id}
                    className="bg-gray-50 rounded-xl p-4"
                    style={{ 
                      opacity: 1,
                      transform: [{ translateY: 0 }],
                    }}
                  >
                    <View className="flex-row items-center justify-between mb-2">
                      <Text className="text-sm font-semibold text-[#264653]">
                        {record.time}
                      </Text>
                      <View className="flex-row items-center gap-2">
                        {record.hasBlood && (
                          <View className="px-2 py-0.5 bg-[#E76F51]/10 rounded-full">
                            <Text className="text-[#E76F51] text-xs">有出血</Text>
                          </View>
                        )}
                        <View className={cn(
                          "px-2 py-0.5 rounded-full",
                          getPainColor(record.painLevel)
                        )}>
                          <Text className="text-white text-xs">疼痛 {record.painLevel}</Text>
                        </View>
                      </View>
                    </View>
                    {record.note && (
                      <Text className="text-sm text-[#777]">{record.note}</Text>
                    )}
                  </View>
                ))}
              </View>
            </ScrollView>
          </Animated.View>
        )}
      </SafeAreaView>
    </Animated.View>
  );
}
