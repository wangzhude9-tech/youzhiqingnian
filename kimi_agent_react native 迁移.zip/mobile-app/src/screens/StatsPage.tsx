import React, { useState, useMemo, useRef, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Animated, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronLeft, TrendingUp, Activity, Droplets, AlertCircle, Download } from 'lucide-react-native';
import { cn, getPainColor } from '@/lib/utils';
import type { PoopRecord, StatsData } from '@/types';

const { width } = Dimensions.get('window');

interface StatsPageProps {
  records: PoopRecord[];
  stats: StatsData;
  onClose: () => void;
  onExport: () => void;
}

export function StatsPage({ records, stats, onClose, onExport }: StatsPageProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'trends'>('overview');

  // Animation values
  const slideAnim = useRef(new Animated.Value(width)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // Calculate weekly data
  const weeklyData = useMemo(() => {
    const data = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const dayRecords = records.filter(r => r.date === dateStr);
      
      data.push({
        day: date.toLocaleDateString('zh-CN', { weekday: 'short' }),
        count: dayRecords.length,
        hasBlood: dayRecords.some(r => r.hasBlood),
        avgPain: dayRecords.length > 0
          ? Math.round(dayRecords.reduce((sum, r) => sum + r.painLevel, 0) / dayRecords.length)
          : 0,
      });
    }
    
    return data;
  }, [records]);

  // Calculate pain distribution
  const painDistribution = useMemo(() => {
    const distribution = Array(6).fill(0);
    records.forEach(r => {
      const level = Math.min(Math.floor(r.painLevel / 2), 5);
      distribution[level]++;
    });
    const max = Math.max(...distribution, 1);
    return distribution.map((count, i) => ({
      range: `${i * 2}-${i * 2 + 1}`,
      count,
      percentage: (count / max) * 100,
      color: getPainColor(i * 2),
    }));
  }, [records]);

  const handleClose = () => {
    Animated.parallel([
      Animated.timing(slideAnim, {
        toValue: width,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start(() => {
      onClose();
    });
  };

  return (
    <Animated.View 
      className="absolute inset-0 bg-[#f7f7f7] z-50"
      style={{
        transform: [{ translateX: slideAnim }],
        opacity: fadeAnim,
      }}
    >
      <SafeAreaView className="flex-1">
        {/* Header */}
        <View className="bg-white px-6 pt-4 pb-4 shadow-sm">
          <View className="flex-row items-center justify-between">
            <TouchableOpacity
              onPress={handleClose}
              className="p-2 -ml-2 rounded-full"
              activeOpacity={0.7}
            >
              <ChevronLeft className="w-6 h-6 text-[#264653]" />
            </TouchableOpacity>
            <Text className="text-xl font-bold text-[#264653]">健康统计</Text>
            <TouchableOpacity
              onPress={onExport}
              className="p-2 rounded-full"
              activeOpacity={0.7}
            >
              <Download className="w-5 h-5 text-[#2A9D8F]" />
            </TouchableOpacity>
          </View>

          {/* Tabs */}
          <View className="flex-row gap-2 mt-4">
            <TouchableOpacity
              onPress={() => setActiveTab('overview')}
              className={cn(
                "flex-1 py-2 rounded-lg items-center",
                activeTab === 'overview'
                  ? "bg-[#2A9D8F]"
                  : "bg-gray-100"
              )}
              activeOpacity={0.8}
            >
              <Text className={cn(
                "text-sm font-semibold",
                activeTab === 'overview' ? "text-white" : "text-[#777]"
              )}>
                概览
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setActiveTab('trends')}
              className={cn(
                "flex-1 py-2 rounded-lg items-center",
                activeTab === 'trends'
                  ? "bg-[#2A9D8F]"
                  : "bg-gray-100"
              )}
              activeOpacity={0.8}
            >
              <Text className={cn(
                "text-sm font-semibold",
                activeTab === 'trends' ? "text-white" : "text-[#777]"
              )}>
                趋势
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Content */}
        <ScrollView className="flex-1 px-4 py-6" showsVerticalScrollIndicator={false}>
          {activeTab === 'overview' ? (
            <View className="space-y-6">
              {/* Key Stats Cards */}
              <View className="flex-row flex-wrap justify-between">
                <View className="w-[48%] bg-white rounded-2xl p-4 shadow-sm mb-4">
                  <View className="flex-row items-center gap-2 mb-2">
                    <View className="w-8 h-8 rounded-full bg-[#2A9D8F]/10 items-center justify-center">
                      <TrendingUp className="w-4 h-4 text-[#2A9D8F]" />
                    </View>
                    <Text className="text-xs text-[#777]">总记录数</Text>
                  </View>
                  <Text className="text-2xl font-bold text-[#264653]">{stats.totalRecords}</Text>
                </View>

                <View className="w-[48%] bg-white rounded-2xl p-4 shadow-sm mb-4">
                  <View className="flex-row items-center gap-2 mb-2">
                    <View className="w-8 h-8 rounded-full bg-[#E76F51]/10 items-center justify-center">
                      <Droplets className="w-4 h-4 text-[#E76F51]" />
                    </View>
                    <Text className="text-xs text-[#777]">出血天数</Text>
                  </View>
                  <Text className="text-2xl font-bold text-[#264653]">{stats.bloodDays}</Text>
                </View>

                <View className="w-[48%] bg-white rounded-2xl p-4 shadow-sm mb-4">
                  <View className="flex-row items-center gap-2 mb-2">
                    <View className="w-8 h-8 rounded-full bg-[#F4A261]/10 items-center justify-center">
                      <Activity className="w-4 h-4 text-[#F4A261]" />
                    </View>
                    <Text className="text-xs text-[#777]">平均疼痛</Text>
                  </View>
                  <Text className="text-2xl font-bold text-[#264653]">{stats.avgPainLevel}</Text>
                </View>

                <View className="w-[48%] bg-white rounded-2xl p-4 shadow-sm mb-4">
                  <View className="flex-row items-center gap-2 mb-2">
                    <View className="w-8 h-8 rounded-full bg-[#E9C46A]/20 items-center justify-center">
                      <AlertCircle className="w-4 h-4 text-[#E9C46A]" />
                    </View>
                    <Text className="text-xs text-[#777]">本月记录</Text>
                  </View>
                  <Text className="text-2xl font-bold text-[#264653]">{stats.thisMonthCount}</Text>
                </View>
              </View>

              {/* Pain Distribution */}
              <View className="bg-white rounded-2xl p-5 shadow-sm">
                <Text className="text-lg font-bold text-[#264653] mb-4">疼痛指数分布</Text>
                <View className="space-y-3">
                  {painDistribution.map((item, index) => (
                    <View key={index} className="flex-row items-center gap-3">
                      <Text className="text-xs text-[#777] w-8">{item.range}</Text>
                      <View className="flex-1 h-6 bg-gray-100 rounded-full overflow-hidden">
                        <View
                          className={cn("h-full rounded-full", item.color)}
                          style={{ width: `${item.percentage}%` }}
                        />
                      </View>
                      <Text className="text-xs text-[#264653] w-6 text-right">{item.count}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          ) : (
            <View className="space-y-6">
              {/* Weekly Trend */}
              <View className="bg-white rounded-2xl p-5 shadow-sm">
                <Text className="text-lg font-bold text-[#264653] mb-4">近7天排便情况</Text>
                <View className="flex-row items-end justify-between h-40">
                  {weeklyData.map((day, index) => (
                    <View key={index} className="flex-1 items-center gap-2">
                      <View className="w-full items-center justify-end" style={{ height: 120 }}>
                        {day.count > 0 ? (
                          <View
                            className={cn(
                              "w-6 rounded-t-lg",
                              day.hasBlood ? "bg-[#E76F51]/60" : "bg-[#2A9D8F]/60"
                            )}
                            style={{ height: Math.min(day.count * 25 + 20, 100) }}
                          />
                        ) : (
                          <View className="w-6 h-2 bg-gray-200 rounded-full" />
                        )}
                      </View>
                      <Text className="text-xs text-[#777]">{day.day}</Text>
                    </View>
                  ))}
                </View>
              </View>

              {/* Pain Trend */}
              <View className="bg-white rounded-2xl p-5 shadow-sm">
                <Text className="text-lg font-bold text-[#264653] mb-4">近7天疼痛趋势</Text>
                <View className="flex-row items-end justify-between h-40">
                  {weeklyData.map((day, index) => (
                    <View key={index} className="flex-1 items-center gap-2">
                      <View className="w-full items-center justify-end" style={{ height: 120 }}>
                        {day.avgPain > 0 ? (
                          <View
                            className={cn("w-6 rounded-t-lg", getPainColor(day.avgPain))}
                            style={{ height: day.avgPain * 10 }}
                          />
                        ) : (
                          <View className="w-6 h-2 bg-gray-200 rounded-full" />
                        )}
                      </View>
                      <Text className="text-xs text-[#777]">{day.day}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          )}
        </ScrollView>
      </SafeAreaView>
    </Animated.View>
  );
}
