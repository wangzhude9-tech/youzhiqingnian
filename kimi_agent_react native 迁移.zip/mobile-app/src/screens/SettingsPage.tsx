import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Animated, Dimensions, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronLeft, Bell, Trash2, FileDown, Info, Moon, Sun } from 'lucide-react-native';
import { cn } from '@/lib/utils';

const { width } = Dimensions.get('window');

interface SettingsPageProps {
  isOpen: boolean;
  onClose: () => void;
  onClearData: () => void;
  onExportData: () => void;
}

export function SettingsPage({ isOpen, onClose, onClearData, onExportData }: SettingsPageProps) {
  const [notifications, setNotifications] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  // Animation values
  const slideAnim = useRef(new Animated.Value(width)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (isOpen) {
      Animated.parallel([
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [isOpen]);

  const handleClose = () => {
    Animated.parallel([
      Animated.timing(slideAnim, {
        toValue: width,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start(() => {
      onClose();
    });
  };

  const handleClearData = () => {
    Alert.alert(
      '确认清除数据？',
      '此操作将永久删除所有历史记录，无法恢复。请谨慎操作。',
      [
        {
          text: '取消',
          style: 'cancel',
        },
        {
          text: '确认清除',
          style: 'destructive',
          onPress: () => {
            onClearData();
          },
        },
      ]
    );
  };

  if (!isOpen) return null;

  return (
    <Animated.View 
      className="absolute inset-0 bg-[#f7f7f7] z-50"
      style={{
        transform: [{ translateX: slideAnim }],
        opacity: fadeAnim,
      }}
    >
      <SafeAreaView className="flex-1">
        {/* Header */}
        <View className="bg-white px-6 pt-4 pb-4 shadow-sm">
          <View className="flex-row items-center justify-between">
            <TouchableOpacity
              onPress={handleClose}
              className="p-2 -ml-2 rounded-full"
              activeOpacity={0.7}
            >
              <ChevronLeft className="w-6 h-6 text-[#264653]" />
            </TouchableOpacity>
            <Text className="text-xl font-bold text-[#264653]">设置</Text>
            <View className="w-10" />
          </View>
        </View>

        {/* Settings Content */}
        <ScrollView className="flex-1 px-4 py-6" showsVerticalScrollIndicator={false}>
          {/* Preferences Section */}
          <View className="bg-white rounded-2xl shadow-sm overflow-hidden mb-6">
            <View className="px-5 py-4 border-b border-gray-100">
              <Text className="text-sm font-semibold text-[#777] uppercase tracking-wide">偏好设置</Text>
            </View>
            
            {/* Notifications */}
            <View className="px-5 py-4 flex-row items-center justify-between border-b border-gray-100">
              <View className="flex-row items-center gap-3">
                <View className="w-10 h-10 rounded-full bg-[#2A9D8F]/10 items-center justify-center">
                  <Bell className="w-5 h-5 text-[#2A9D8F]" />
                </View>
                <View>
                  <Text className="font-semibold text-[#264653]">每日提醒</Text>
                  <Text className="text-xs text-[#777]">定时提醒记录排便情况</Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => setNotifications(!notifications)}
                className={cn(
                  "w-14 h-8 rounded-full relative",
                  notifications ? "bg-[#2A9D8F]" : "bg-gray-300"
                )}
                activeOpacity={0.8}
              >
                <Animated.View
                  className="absolute top-1 w-6 h-6 rounded-full bg-white shadow-md"
                  style={{
                    left: notifications ? 28 : 4,
                  }}
                />
              </TouchableOpacity>
            </View>

            {/* Dark Mode */}
            <View className="px-5 py-4 flex-row items-center justify-between">
              <View className="flex-row items-center gap-3">
                <View className="w-10 h-10 rounded-full bg-[#264653]/10 items-center justify-center">
                  {darkMode ? (
                    <Moon className="w-5 h-5 text-[#264653]" />
                  ) : (
                    <Sun className="w-5 h-5 text-[#F4A261]" />
                  )}
                </View>
                <View>
                  <Text className="font-semibold text-[#264653]">深色模式</Text>
                  <Text className="text-xs text-[#777]">切换应用主题</Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => setDarkMode(!darkMode)}
                className={cn(
                  "w-14 h-8 rounded-full relative",
                  darkMode ? "bg-[#264653]" : "bg-gray-300"
                )}
                activeOpacity={0.8}
              >
                <Animated.View
                  className="absolute top-1 w-6 h-6 rounded-full bg-white shadow-md"
                  style={{
                    left: darkMode ? 28 : 4,
                  }}
                />
              </TouchableOpacity>
            </View>
          </View>

          {/* Data Section */}
          <View className="bg-white rounded-2xl shadow-sm overflow-hidden mb-6">
            <View className="px-5 py-4 border-b border-gray-100">
              <Text className="text-sm font-semibold text-[#777] uppercase tracking-wide">数据管理</Text>
            </View>
            
            {/* Export Data */}
            <TouchableOpacity
              onPress={onExportData}
              className="px-5 py-4 flex-row items-center justify-between border-b border-gray-100"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center gap-3">
                <View className="w-10 h-10 rounded-full bg-[#E9C46A]/20 items-center justify-center">
                  <FileDown className="w-5 h-5 text-[#E9C46A]" />
                </View>
                <View>
                  <Text className="font-semibold text-[#264653]">导出数据</Text>
                  <Text className="text-xs text-[#777]">将记录导出为JSON文件</Text>
                </View>
              </View>
              <ChevronLeft className="w-5 h-5 text-[#777]" style={{ transform: [{ rotate: '180deg' }] }} />
            </TouchableOpacity>

            {/* Clear Data */}
            <TouchableOpacity
              onPress={handleClearData}
              className="px-5 py-4 flex-row items-center justify-between"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center gap-3">
                <View className="w-10 h-10 rounded-full bg-[#E76F51]/10 items-center justify-center">
                  <Trash2 className="w-5 h-5 text-[#E76F51]" />
                </View>
                <View>
                  <Text className="font-semibold text-[#E76F51]">清除所有数据</Text>
                  <Text className="text-xs text-[#777]">删除所有历史记录（不可恢复）</Text>
                </View>
              </View>
              <ChevronLeft className="w-5 h-5 text-[#777]" style={{ transform: [{ rotate: '180deg' }] }} />
            </TouchableOpacity>
          </View>

          {/* About Section */}
          <View className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <View className="px-5 py-4 border-b border-gray-100">
              <Text className="text-sm font-semibold text-[#777] uppercase tracking-wide">关于</Text>
            </View>
            
            <View className="px-5 py-4 flex-row items-center gap-3">
              <View 
                className="w-12 h-12 rounded-2xl items-center justify-center"
                style={{ backgroundColor: '#2A9D8F' }}
              >
                <Text className="text-2xl">💩</Text>
              </View>
              <View>
                <Text className="font-bold text-[#264653]">有痔青年</Text>
                <Text className="text-xs text-[#777]">版本 1.0.0</Text>
              </View>
            </View>

            <View className="px-5 py-4 border-t border-gray-100">
              <Text className="text-sm text-[#777] leading-relaxed">
                有痔青年是一款专为关注肠道健康的年轻人设计的健康追踪应用。
                我们希望通过轻松幽默的方式，帮助大家养成良好的健康记录习惯。
              </Text>
            </View>

            <View className="px-5 py-4 border-t border-gray-100 flex-row items-center gap-2">
              <Info className="w-4 h-4 text-[#2A9D8F]" />
              <Text className="text-xs text-[#777]">
                如有严重症状，请及时就医
              </Text>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </Animated.View>
  );
}
