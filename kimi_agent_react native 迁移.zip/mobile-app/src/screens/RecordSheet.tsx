import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { View, Text, TouchableOpacity, TextInput, ScrollView, Animated } from 'react-native';
import BottomSheet, { BottomSheetView, BottomSheetBackdrop } from '@gorhom/bottom-sheet';
import { Clock, Droplets, AlertCircle, MessageSquare } from 'lucide-react-native';
import { cn, getCurrentTime, getCurrentDate, getPainText, getPainTextColor } from '@/lib/utils';
import { BloodAmountLabels, PainEmojis } from '@/types';
import type { PoopRecord, BloodAmount } from '@/types';

interface RecordSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: Omit<PoopRecord, 'id'>) => void;
}

export function RecordSheet({ isOpen, onClose, onSave }: RecordSheetProps) {
  const bottomSheetRef = useRef<BottomSheet>(null);
  
  const [time, setTime] = useState(getCurrentTime());
  const [hasBlood, setHasBlood] = useState(false);
  const [bloodAmount, setBloodAmount] = useState<BloodAmount | undefined>();
  const [painLevel, setPainLevel] = useState(0);
  const [note, setNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Animation for blood options
  const bloodOptionsHeight = useRef(new Animated.Value(0)).current;
  const bloodOptionsOpacity = useRef(new Animated.Value(0)).current;

  // Snap points
  const snapPoints = useMemo(() => ['85%'], []);

  // Reset form when opened
  useEffect(() => {
    if (isOpen) {
      setTime(getCurrentTime());
      setHasBlood(false);
      setBloodAmount(undefined);
      setPainLevel(0);
      setNote('');
      setIsSubmitting(false);
      bottomSheetRef.current?.expand();
    } else {
      bottomSheetRef.current?.close();
    }
  }, [isOpen]);

  // Animate blood options
  useEffect(() => {
    if (hasBlood) {
      Animated.parallel([
        Animated.timing(bloodOptionsHeight, {
          toValue: 220,
          duration: 300,
          useNativeDriver: false,
        }),
        Animated.timing(bloodOptionsOpacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(bloodOptionsHeight, {
          toValue: 0,
          duration: 300,
          useNativeDriver: false,
        }),
        Animated.timing(bloodOptionsOpacity, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
      setBloodAmount(undefined);
    }
  }, [hasBlood]);

  const handleSave = useCallback(() => {
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    
    const date = getCurrentDate();
    const [hours, minutes] = time.split(':');
    const timestamp = new Date(`${date}T${hours}:${minutes}:00`).getTime();
    
    onSave({
      timestamp,
      date,
      time,
      hasBlood,
      bloodAmount: hasBlood ? bloodAmount : undefined,
      painLevel,
      note: note.trim(),
    });
    
    setTimeout(() => {
      onClose();
      setIsSubmitting(false);
    }, 300);
  }, [time, hasBlood, bloodAmount, painLevel, note, isSubmitting, onSave, onClose]);

  const handleSheetChanges = useCallback((index: number) => {
    if (index === -1) {
      onClose();
    }
  }, [onClose]);

  const renderBackdrop = useCallback(
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
        opacity={0.5}
      />
    ),
    []
  );

  return (
    <BottomSheet
      ref={bottomSheetRef}
      index={isOpen ? 0 : -1}
      snapPoints={snapPoints}
      onChange={handleSheetChanges}
      backdropComponent={renderBackdrop}
      enablePanDownToClose
      backgroundStyle={{ backgroundColor: '#fff', borderRadius: 24 }}
      handleIndicatorStyle={{ backgroundColor: '#d1d5db', width: 40 }}
    >
      <BottomSheetView className="flex-1 px-6">
        {/* Header */}
        <View className="flex-row items-center justify-between py-4 border-b border-gray-100">
          <Text className="text-xl font-bold text-[#264653]">记录今日</Text>
          <TouchableOpacity
            onPress={onClose}
            className="p-2 rounded-full bg-gray-100"
            activeOpacity={0.7}
          >
            <Text className="text-[#777] text-lg">✕</Text>
          </TouchableOpacity>
        </View>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          {/* Time Field */}
          <View className="mb-6 mt-4">
            <View className="flex-row items-center gap-2 mb-3">
              <Clock className="w-4 h-4 text-[#2A9D8F]" />
              <Text className="text-sm font-semibold text-[#264653]">排便时间</Text>
            </View>
            <View className="flex-row items-center">
              <TextInput
                value={time}
                onChangeText={setTime}
                placeholder="HH:MM"
                className="flex-1 px-4 py-3 bg-gray-50 rounded-xl text-lg text-[#264653]"
              />
            </View>
          </View>

          {/* Blood Toggle */}
          <View className="mb-6">
            <View className="flex-row items-center gap-2 mb-3">
              <Droplets className="w-4 h-4 text-[#E76F51]" />
              <Text className="text-sm font-semibold text-[#264653]">是否有血</Text>
            </View>
            <View className="flex-row gap-3">
              <TouchableOpacity
                onPress={() => setHasBlood(false)}
                className={cn(
                  "flex-1 py-4 rounded-xl items-center",
                  !hasBlood 
                    ? "bg-[#2A9D8F]" 
                    : "bg-gray-100"
                )}
                activeOpacity={0.8}
              >
                <Text className={cn(
                  "font-semibold",
                  !hasBlood ? "text-white" : "text-[#777]"
                )}>
                  没有出血
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => setHasBlood(true)}
                className={cn(
                  "flex-1 py-4 rounded-xl items-center",
                  hasBlood 
                    ? "bg-[#E76F51]" 
                    : "bg-gray-100"
                )}
                activeOpacity={0.8}
              >
                <Text className={cn(
                  "font-semibold",
                  hasBlood ? "text-white" : "text-[#777]"
                )}>
                  有出血
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Blood Amount (conditional) */}
          <Animated.View 
            style={{ 
              height: bloodOptionsHeight,
              opacity: bloodOptionsOpacity,
              overflow: 'hidden',
              marginBottom: hasBlood ? 24 : 0,
            }}
          >
            <View className="flex-row items-center gap-2 mb-3">
              <AlertCircle className="w-4 h-4 text-[#E76F51]" />
              <Text className="text-sm font-semibold text-[#264653]">出血量</Text>
            </View>
            <View className="space-y-2">
              {(Object.keys(BloodAmountLabels) as BloodAmount[]).map((value) => (
                <TouchableOpacity
                  key={value}
                  onPress={() => setBloodAmount(value)}
                  className={cn(
                    "px-4 py-3 rounded-xl flex-row items-center justify-between",
                    bloodAmount === value
                      ? "bg-[#E76F51]/10 border-2 border-[#E76F51]"
                      : "bg-gray-50 border-2 border-transparent"
                  )}
                  activeOpacity={0.7}
                >
                  <Text className={cn(
                    "text-sm",
                    bloodAmount === value ? "text-[#E76F51]" : "text-[#264653]"
                  )}>
                    {BloodAmountLabels[value]}
                  </Text>
                  {bloodAmount === value && (
                    <View className="w-5 h-5 rounded-full bg-[#E76F51] items-center justify-center">
                      <Text className="text-white text-xs">✓</Text>
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </Animated.View>

          {/* Pain Level Slider */}
          <View className="mb-6">
            <View className="flex-row items-center gap-2 mb-3">
              <Text className="text-lg">{PainEmojis[painLevel]}</Text>
              <Text className="text-sm font-semibold text-[#264653]">疼痛指数</Text>
            </View>
            <View className="bg-gray-50 rounded-xl p-4">
              <View className="flex-row items-center justify-between mb-3">
                <Text className="text-xs text-[#777]">无感</Text>
                <Text className={cn("text-lg font-bold", getPainTextColor(painLevel))}>
                  {painLevel}
                </Text>
                <Text className="text-xs text-[#777]">剧痛</Text>
              </View>
              
              {/* Custom Slider */}
              <View className="flex-row justify-between items-center px-1">
                {Array.from({ length: 11 }, (_, i) => (
                  <TouchableOpacity
                    key={i}
                    onPress={() => setPainLevel(i)}
                    className="items-center"
                    activeOpacity={0.7}
                  >
                    <View 
                      className={cn(
                        "w-6 h-6 rounded-full items-center justify-center",
                        i === painLevel 
                          ? "bg-[#2A9D8F]" 
                          : i < painLevel 
                            ? "bg-[#2A9D8F]/50" 
                            : "bg-gray-300"
                      )}
                    >
                      <Text className={cn(
                        "text-xs",
                        i <= painLevel ? "text-white" : "text-gray-500"
                      )}>
                        {i}
                      </Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
              
              <Text className="text-center text-sm text-[#777] mt-3">
                {getPainText(painLevel)}
              </Text>
            </View>
          </View>

          {/* Note Field */}
          <View className="mb-6">
            <View className="flex-row items-center gap-2 mb-3">
              <MessageSquare className="w-4 h-4 text-[#F4A261]" />
              <Text className="text-sm font-semibold text-[#264653]">备注</Text>
            </View>
            <TextInput
              value={note}
              onChangeText={setNote}
              placeholder="记录一下今天的饮食或感受..."
              multiline
              numberOfLines={3}
              className="px-4 py-3 bg-gray-50 rounded-xl text-sm text-[#264653]"
              style={{ textAlignVertical: 'top', minHeight: 80 }}
            />
          </View>

          {/* Save Button */}
          <TouchableOpacity
            onPress={handleSave}
            disabled={isSubmitting}
            className={cn(
              "py-4 rounded-xl items-center mb-8",
              isSubmitting ? "opacity-70" : ""
            )}
            style={{
              backgroundColor: '#2A9D8F',
            }}
            activeOpacity={0.8}
          >
            <Text className="font-bold text-white text-lg">
              {isSubmitting ? '保存中...' : '保存记录'}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </BottomSheetView>
    </BottomSheet>
  );
}
