/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./App.tsx",
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        background: "#F7F7F7",
        foreground: "#333333",
        primary: {
          DEFAULT: "#2A9D8F",
          foreground: "#FFFFFF",
        },
        secondary: {
          DEFAULT: "#E9C46A",
          foreground: "#264653",
        },
        accent: {
          DEFAULT: "#F4A261",
          foreground: "#264653",
        },
        destructive: {
          DEFAULT: "#E76F51",
          foreground: "#FFFFFF",
        },
        muted: {
          DEFAULT: "#F7F7F7",
          foreground: "#777777",
        },
        card: {
          DEFAULT: "#FFFFFF",
          foreground: "#264653",
        },
        teal: "#2A9D8F",
        "teal-dark": "#264653",
        yellow: "#E9C46A",
        orange: "#F4A261",
        coral: "#E76F51",
        "gray-light": "#F7F7F7",
        "gray-text": "#777777",
      },
      borderRadius: {
        "2xl": "1rem",
        "3xl": "1.5rem",
      },
    },
  },
  plugins: [],
};
